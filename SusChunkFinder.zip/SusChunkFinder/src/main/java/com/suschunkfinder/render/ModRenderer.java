package com.suschunkfinder.render;

import com.mojang.blaze3d.systems.RenderSystem;
import com.suschunkfinder.config.ModConfig;
import com.suschunkfinder.module.PlayerDebugModule;
import com.suschunkfinder.module.StorageEspModule;
import com.suschunkfinder.module.SusChunkModule;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

public class ModRenderer {

    public static void render(WorldRenderContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null || client.player == null) return;

        MatrixStack matrices = context.matrixStack();
        Vec3d cam = context.camera().getPos();
        matrices.push();
        matrices.translate(-cam.x, -cam.y, -cam.z);

        Tessellator tessellator = Tessellator.getInstance();

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);
        RenderSystem.lineWidth(2.0f);

        // === OUTLINES ===
        BufferBuilder buffer = tessellator.begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);

        // Sus Chunks outline
        if (ModConfig.susChunkEnabled) {
            for (SusChunkModule.ChunkData data : SusChunkModule.getSusChunks().values()) {
                int color = data.percent >= 50 ? ModConfig.highPercentColor : ModConfig.outlineColor;
                if (ModConfig.showOutline) {
                    drawChunkOutline(buffer, matrices, data.pos, color);
                }
            }
        }

        // Player Debug chunks
        if (ModConfig.playerDebugEnabled) {
            for (Long key : PlayerDebugModule.getPlayerChunks()) {
                ChunkPos pos = new ChunkPos(key);
                drawChunkOutline(buffer, matrices, pos, ModConfig.playerChunkColor);
            }
        }

        // Storage ESP
        if (ModConfig.storageEspEnabled) {
            int espColor = ModConfig.storageEspColor;
            for (BlockPos pos : StorageEspModule.storagePositions) {
                drawBoxOutline(buffer, matrices, pos, espColor);
            }
        }

        BufferRenderer.drawWithGlobalProgram(buffer.end());

        // === FILLS ===
        if (ModConfig.showFill) {
            buffer = tessellator.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
            if (ModConfig.susChunkEnabled) {
                for (SusChunkModule.ChunkData data : SusChunkModule.getSusChunks().values()) {
                    int color = data.percent >= 50 ? ModConfig.highPercentColor : ModConfig.fillColor;
                    drawChunkFill(buffer, matrices, data.pos, color);
                }
            }
            if (ModConfig.playerDebugEnabled) {
                for (Long key : PlayerDebugModule.getPlayerChunks()) {
                    ChunkPos pos = new ChunkPos(key);
                    drawChunkFill(buffer, matrices, pos, ModConfig.playerFillColor);
                }
            }
            BufferRenderer.drawWithGlobalProgram(buffer.end());
        }

        // === PERCENT TEXT ===
        if (ModConfig.showPercent && ModConfig.susChunkEnabled && context.consumers() != null) {
            for (SusChunkModule.ChunkData data : SusChunkModule.getSusChunks().values()) {
                renderPercentText(context, data, cam);
            }
        }

        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
        matrices.pop();
    }

    private static void drawChunkOutline(BufferBuilder buffer, MatrixStack matrices, ChunkPos pos, int color) {
        float a = ((color >> 24) & 0xFF) / 255f;
        if (a <= 0) a = 1f;
        float r = ((color >> 16) & 0xFF) / 255f;
        float g = ((color >> 8) & 0xFF) / 255f;
        float b = (color & 0xFF) / 255f;

        int x1 = pos.getStartX();
        int z1 = pos.getStartZ();
        int x2 = x1 + 16;
        int z2 = z1 + 16;
        int y1 = MinecraftClient.getInstance().world.getBottomY();
        int y2 = Math.max(y1 + 1, ModConfig.scanYLevel + 1);

        Matrix4f matrix = matrices.peek().getPositionMatrix();

        // Bottom
        line(buffer, matrix, x1, y1, z1, x2, y1, z1, r, g, b, a);
        line(buffer, matrix, x2, y1, z1, x2, y1, z2, r, g, b, a);
        line(buffer, matrix, x2, y1, z2, x1, y1, z2, r, g, b, a);
        line(buffer, matrix, x1, y1, z2, x1, y1, z1, r, g, b, a);

        // Top
        line(buffer, matrix, x1, y2, z1, x2, y2, z1, r, g, b, a);
        line(buffer, matrix, x2, y2, z1, x2, y2, z2, r, g, b, a);
        line(buffer, matrix, x2, y2, z2, x1, y2, z2, r, g, b, a);
        line(buffer, matrix, x1, y2, z2, x1, y2, z1, r, g, b, a);

        // Verticals
        line(buffer, matrix, x1, y1, z1, x1, y2, z1, r, g, b, a);
        line(buffer, matrix, x2, y1, z1, x2, y2, z1, r, g, b, a);
        line(buffer, matrix, x2, y1, z2, x2, y2, z2, r, g, b, a);
        line(buffer, matrix, x1, y1, z2, x1, y2, z2, r, g, b, a);
    }

    private static void drawChunkFill(BufferBuilder buffer, MatrixStack matrices, ChunkPos pos, int color) {
        float a = ModConfig.fillOpacity;
        float r = ((color >> 16) & 0xFF) / 255f;
        float g = ((color >> 8) & 0xFF) / 255f;
        float b = (color & 0xFF) / 255f;

        int x1 = pos.getStartX();
        int z1 = pos.getStartZ();
        int x2 = x1 + 16;
        int z2 = z1 + 16;
        int y1 = MinecraftClient.getInstance().world.getBottomY();
        int y2 = Math.max(y1 + 1, ModConfig.scanYLevel + 1);

        Matrix4f matrix = matrices.peek().getPositionMatrix();

        // 4 side faces
        quad(buffer, matrix, x1, y1, z1, x2, y1, z1, x2, y2, z1, x1, y2, z1, r, g, b, a);
        quad(buffer, matrix, x1, y1, z2, x1, y2, z2, x2, y2, z2, x2, y1, z2, r, g, b, a);
        quad(buffer, matrix, x1, y1, z1, x1, y2, z1, x1, y2, z2, x1, y1, z2, r, g, b, a);
        quad(buffer, matrix, x2, y1, z1, x2, y1, z2, x2, y2, z2, x2, y2, z1, r, g, b, a);
    }

    private static void drawBoxOutline(BufferBuilder buffer, MatrixStack matrices, BlockPos pos, int color) {
        float a = ((color >> 24) & 0xFF) / 255f;
        if (a <= 0) a = 1f;
        float r = ((color >> 16) & 0xFF) / 255f;
        float g = ((color >> 8) & 0xFF) / 255f;
        float b = (color & 0xFF) / 255f;

        float x1 = pos.getX();
        float y1 = pos.getY();
        float z1 = pos.getZ();
        float x2 = x1 + 1;
        float y2 = y1 + 1;
        float z2 = z1 + 1;

        Matrix4f matrix = matrices.peek().getPositionMatrix();

        line(buffer, matrix, x1, y1, z1, x2, y1, z1, r, g, b, a);
        line(buffer, matrix, x2, y1, z1, x2, y1, z2, r, g, b, a);
        line(buffer, matrix, x2, y1, z2, x1, y1, z2, r, g, b, a);
        line(buffer, matrix, x1, y1, z2, x1, y1, z1, r, g, b, a);

        line(buffer, matrix, x1, y2, z1, x2, y2, z1, r, g, b, a);
        line(buffer, matrix, x2, y2, z1, x2, y2, z2, r, g, b, a);
        line(buffer, matrix, x2, y2, z2, x1, y2, z2, r, g, b, a);
        line(buffer, matrix, x1, y2, z2, x1, y2, z1, r, g, b, a);

        line(buffer, matrix, x1, y1, z1, x1, y2, z1, r, g, b, a);
        line(buffer, matrix, x2, y1, z1, x2, y2, z1, r, g, b, a);
        line(buffer, matrix, x2, y1, z2, x2, y2, z2, r, g, b, a);
        line(buffer, matrix, x1, y1, z2, x1, y2, z2, r, g, b, a);
    }

    private static void line(BufferBuilder buffer, Matrix4f matrix, float x1, float y1, float z1, float x2, float y2, float z2, float r, float g, float b, float a) {
        buffer.vertex(matrix, x1, y1, z1).color(r, g, b, a);
        buffer.vertex(matrix, x2, y2, z2).color(r, g, b, a);
    }

    private static void quad(BufferBuilder buffer, Matrix4f matrix,
                             float x1, float y1, float z1,
                             float x2, float y2, float z2,
                             float x3, float y3, float z3,
                             float x4, float y4, float z4,
                             float r, float g, float b, float a) {
        buffer.vertex(matrix, x1, y1, z1).color(r, g, b, a);
        buffer.vertex(matrix, x2, y2, z2).color(r, g, b, a);
        buffer.vertex(matrix, x3, y3, z3).color(r, g, b, a);
        buffer.vertex(matrix, x4, y4, z4).color(r, g, b, a);
    }

    private static void renderPercentText(WorldRenderContext context, SusChunkModule.ChunkData data, Vec3d cam) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.textRenderer == null) return;

        ChunkPos pos = data.pos;
        double x = pos.getStartX() + 8.0;
        double y = ModConfig.scanYLevel + 3.0;
        double z = pos.getStartZ() + 8.0;

        double distSq = (x - cam.x) * (x - cam.x) + (z - cam.z) * (z - cam.z);
        if (distSq > 80 * 80) return;

        MatrixStack matrices = context.matrixStack();
        matrices.push();
        matrices.translate(x - cam.x, y - cam.y, z - cam.z);
        matrices.multiply(context.camera().getRotation());
        matrices.scale(-0.04f, -0.04f, 0.04f);

        String text = data.percent + "%";
        if (data.spawnerCount > 0) text += " S" + data.spawnerCount;
        if (data.chestCount > 0) text += " C" + data.chestCount;

        float width = client.textRenderer.getWidth(text);
        int color = data.percent >= 50 ? 0xFFFF5500 : 0xFFFFFFFF;

        client.textRenderer.draw(
                text,
                -width / 2f,
                0,
                color,
                false,
                matrices.peek().getPositionMatrix(),
                context.consumers(),
                TextRenderer.TextLayerType.SEE_THROUGH,
                0x80000000,
                0xF000F0
        );

        matrices.pop();
    }
}
