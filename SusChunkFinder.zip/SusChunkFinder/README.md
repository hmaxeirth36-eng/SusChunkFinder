# Sus Chunk Finder

Minecraft Fabric 1.21.1 Client Mod

## Features
- **Sus Chunk Finder**: Detects underground chunks with chests, barrels, shulkers, hoppers, redstone systems and spawners.
  - Draws chunk outline
  - Optional fill color
  - Shows % chance of base
- **Player Debug**: Highlights chunks where other players are underground (Y <= configurable)
- **Storage ESP**: Shows outlines of storage blocks through walls
- Fully configurable GUI (press `\`)

## How to use
1. Install Fabric Loader for 1.21.1
2. Install Fabric API
3. Put the mod jar in `.minecraft/mods`
4. Press `\` in-game to open config

## Building
```bash
./gradlew build
```
The jar will be in `build/libs/`

## Notes
- This is a **client-side only** mod.
- Scanning is limited for performance.
- Colors and thresholds are adjustable in the GUI / config file (`config/suschunkfinder.json`)
